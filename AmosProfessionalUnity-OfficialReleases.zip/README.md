# AmosProfessionalUnity-Official-Releases

Here is the official repository for the Amos Professional Unity binaries releases.
Amos Professional Unity is based on François Lionet Amos Professional whose official source code repository is :
https://github.com/AOZ-Studio/AMOS-Professional-Official

Unity mean "unite all Amiga 68k compatibles configurations around Amos Professional"

# Official Homepage of the project :
http://amos-professional-aga.frederic-cordier.fr/

# New commands available in the Public Alpha Release 2 :
http://amos-professional-aga.frederic-cordier.fr/?amos-professional-unity-alpha-release-2-coming-soon

# New commands available in the Public Alpha Release 1 :
http://amos-professional-aga.frederic-cordier.fr/?amos-professional-unity-alpha-release-1


# Official RoadMap :
http://amos-professional-aga.frederic-cordier.fr/?roadmap-2021

# Developer diary :
http://amos-professional-aga.frederic-cordier.fr/?developer-diary

# Youtube Channel :
https://www.youtube.com/channel/UCCfoSCwQe2RTd13Kh56v2Rw